// Använd en unik nyckel för denna specifika bloggplattform
const STORAGE_KEY = 'blogPosts_platform1';

// Hämta sparade inlägg från localStorage eller skapa en tom array
let blogPosts = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];

// DOM-element
const blogForm = document.getElementById('blogForm');
const postsContainer = document.getElementById('posts-container');

// Funktion för att spara inlägg till localStorage
function savePosts() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(blogPosts));
}

// Funktion för att skapa ett nytt inlägg
function createPost(title, author, content) {
    const post = {
        id: Date.now(),
        title,
        author,
        content,
        date: new Date().toLocaleDateString('sv-SE'),
        time: new Date().toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit' }),
        comments: [],
        ratings: []
    };
    blogPosts.unshift(post);
    savePosts();
    displayPosts();
}

function deletePost(postId) {
    if (confirm('Är du säker på att du vill ta bort detta inlägg?')) {
        blogPosts = blogPosts.filter(post => post.id !== postId);
        savePosts();
        displayPosts();
    }
}

// Funktion för att lägga till en kommentar
function addComment(postId, author, content) {
    const post = blogPosts.find(p => p.id === postId);
    if (post) {
        const comment = {
            id: Date.now(),
            author,
            content,
            date: new Date().toLocaleDateString('sv-SE'),
            time: new Date().toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit' })
        };
        post.comments.push(comment);
        savePosts();
        displayPosts();
    }
}

// Funktion för att ta bort en kommentar
function deleteComment(postId, commentId) {
    if (confirm('Är du säker på att du vill ta bort denna kommentar?')) {
        const post = blogPosts.find(p => p.id === postId);
        if (post) {
            post.comments = post.comments.filter(comment => comment.id !== commentId);
            savePosts();
            displayPosts();
        }
    }
}

// Funktion för att lägga till betyg
function addRating(postId, rating) {
    const post = blogPosts.find(p => p.id === postId);
    if (post) {
        post.ratings.push(rating);
        savePosts();
        displayPosts();
    }
}

// Funktion för att beräkna genomsnittligt betyg
function calculateAverageRating(ratings) {
    if (ratings.length === 0) return 0;
    return ratings.reduce((a, b) => a + b, 0) / ratings.length;
}

// Funktion för att generera stjärnbetyg HTML
function generateStarRating(postId, ratings) {
    const averageRating = calculateAverageRating(ratings);
    let html = '<div class="rating">';
    for (let i = 1; i <= 5; i++) {
        html += `<span class="star ${averageRating >= i ? 'filled' : ''}" 
                      onclick="addRating(${postId}, ${i})">★</span>`;
    }
    html += `<span class="rating-text">(${averageRating.toFixed(1)})</span></div>`;
    return html;
}

// Funktion för att visa alla inlägg
function displayPosts() {
    postsContainer.innerHTML = '';
    blogPosts.forEach(post => {
        const postElement = document.createElement('article');
        postElement.className = 'post';
        postElement.innerHTML = `
            <div class="post-header">
                <div class="post-header-content">
                    <h3 class="post-title">${post.title}</h3>
                    <div class="post-meta">
                        <span>Namn: ${post.author}</span>
                        <span> | </span>
                        <span>Datum: ${post.date} kl. ${post.time}</span>
                    </div>
                </div>
                <button class="delete-button" onclick="deletePost(${post.id})">Ta bort</button>
            </div>
            <div class="post-content">
                ${post.content.replace(/\n/g, '<br>')}
            </div>
            ${generateStarRating(post.id, post.ratings || [])}
            <div class="comments-section">
                <h4>Kommentarer (${post.comments ? post.comments.length : 0})</h4>
                <div class="comments-list">
                    ${(post.comments || []).map(comment => `
                        <div class="comment">
                            <div class="comment-header">
                                <div class="comment-meta">
                                    <strong>${comment.author}</strong> - ${comment.date} kl. ${comment.time}
                                </div>
                                <button class="delete-comment-button" onclick="deleteComment(${post.id}, ${comment.id})">Ta bort</button>
                            </div>
                            <div class="comment-content">${comment.content}</div>
                        </div>
                    `).join('')}
                </div>
                <form class="comment-form" onsubmit="event.preventDefault(); 
                    addComment(${post.id}, 
                    this.querySelector('.comment-author').value, 
                    this.querySelector('.comment-content').value); 
                    this.reset();">
                    <input type="text" class="comment-author" placeholder="Ditt namn" required>
                    <textarea class="comment-content" placeholder="Skriv en kommentar..." required></textarea>
                    <button type="submit">Lägg till kommentar</button>
                </form>
            </div>
        `;
        postsContainer.appendChild(postElement);
    });
}

// Hantera formulärets submit-event
blogForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    const content = document.getElementById('content').value;
    
    createPost(title, author, content);
    
    // Återställ formuläret
    blogForm.reset();
});

// Visa befintliga inlägg när sidan laddas
displayPosts();